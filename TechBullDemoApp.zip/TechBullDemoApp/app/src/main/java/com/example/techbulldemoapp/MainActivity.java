package com.example.techbulldemoapp;

import android.os.Bundle;

import com.example.techbulldemoapp.model.ResponseModel;
import com.example.techbulldemoapp.retrofit.RetroApi;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {

    private static final String URL = "http://www.omdbapi.com/?s=superman&apikey=a92194c2";

    private static final String TAG = "MainActivity";


    private RecyclerView rv;
    private MyAdapter adapter;
    private List<Model> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        callApi();

        //sv= (SearchView) findViewById(R.id.mSearch);
        rv= (RecyclerView) findViewById(R.id.myRecycler);
        //SET ITS PROPERTIES
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setItemAnimator(new DefaultItemAnimator());

        //ADAPTER
       /* adapter=new MyAdapter(this,getPlayers());
        rv.setAdapter(adapter);*/


    }

    //ADD PLAYERS TO ARRAYLIST
    private ArrayList<Model> getPlayers() {
        ArrayList<Model> players=new ArrayList<>();
        Model p=new Model();
        p.setName("Home");
        p.setImg(R.drawable.ic_launcher_foreground);
        players.add(p);

        p=new Model();
        p.setName("Contacts");
        p.setImg(R.drawable.ic_launcher_foreground);
        players.add(p);

        p=new Model();
        p.setName("Images");
        p.setImg(R.drawable.ic_launcher_foreground);
        players.add(p);

        p=new Model();
        p.setName("Videos");
        p.setImg(R.drawable.ic_launcher_foreground);
        players.add(p);

        p=new Model();
        p.setName("Mails");
        p.setImg(R.drawable.ic_launcher_foreground);
        players.add(p);

        return players;

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu, menu);
        final MenuItem item = menu.findItem(R.id.action_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(item);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String query) {
                //FILTER AS YOU TYPE
                adapter.getFilter().filter(query);
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement

        return true;
    }


    public void callApi(){


        new RetroApi().getConnection().getMovieDetails("spiderman", "a92194c2").enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {

                Toast.makeText(getApplicationContext(),response.body().getSearch().get(0).getTitle(),Toast.LENGTH_LONG).show();
                Log.i("SUCCESS",
                        response.body().getSearch().get(0).getTitle()+
                            response.body().getSearch().get(0).getYear() +
                            response.body().getSearch().get(0).getPoster());

                ArrayList<Model> players=new ArrayList<>();
                for(int i = 0; i<response.body().getSearch().size(); i++ ){

                    Model p=new Model();
                    p.setName(response.body().getSearch().get(i).getTitle());
                    p.setImageUrl(response.body().getSearch().get(i).getPoster());
                    players.add(p);

                }
                adapter=new MyAdapter(MainActivity.this,players);
                rv.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                Log.i("ErrorMsg",t.toString());
            }
        });




    }



}
