package com.example.techbulldemoapp.retrofit;

import com.example.techbulldemoapp.model.ResponseModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;

/**
 * Created by Dell on 15-03-2018.
 */

public interface ServerUrlConnection {

    String URL = "http://www.omdbapi.com";
// /?s=superman&apikey=a92194c2

  /*  s=superman&apikey=a92194c2 */

    @POST("/?s=batman&apikey=a92194c2")
    @FormUrlEncoded
    Call<ResponseModel> getMovieDetails(@Field("s") String bookingID,
                                        @Field("apikey") String ride_Code);



}
