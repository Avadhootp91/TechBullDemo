package com.example.techbulldemoapp;

import android.view.View;

/**
 * Created by Atif on 11/3/2018.
 * devofandroid.blogspot.com
 */

public interface ItemClickListener {
    void onItemClick(View v, int pos);
}