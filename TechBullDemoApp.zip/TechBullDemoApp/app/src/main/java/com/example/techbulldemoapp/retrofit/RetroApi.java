package com.example.techbulldemoapp.retrofit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Dell on 15-03-2018.
 */

public class RetroApi {

   /* Gson gson = new GsonBuilder()
            .setLenient()
            .create();

    Retrofit retrofitDriver = new Retrofit.Builder()
            .baseUrl(ServerUrlConnection.URL)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build();*/


    Retrofit retrofitDriver = new Retrofit.Builder()
            .baseUrl(ServerUrlConnection.URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build();


    public ServerUrlConnection getConnection() {

        ServerUrlConnection connection = retrofitDriver.create(ServerUrlConnection.class);
        return connection;

    }
    }
